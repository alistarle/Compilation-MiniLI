package ast;

/**
 * Created by thomas on 22/02/16.
 */
public abstract class Assign extends Instruction {

}
