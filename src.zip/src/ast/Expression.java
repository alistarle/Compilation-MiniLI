package ast;

public abstract class Expression extends Ast {
	
}
