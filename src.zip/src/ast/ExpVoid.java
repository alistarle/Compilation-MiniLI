package ast;

/**
 * Created by thomas on 22/02/16.
 */
public class ExpVoid extends Expression {

}
