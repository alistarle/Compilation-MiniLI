package ast;

public abstract class Ast {
	public Position pos;
}


