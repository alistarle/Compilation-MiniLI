/**
 * 
 */
package ast;

public abstract class Instruction extends Ast {

}
