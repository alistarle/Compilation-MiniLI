package ast;

public enum Binop { ADD, SUB, MUL, DIV, GT, GTE, LT, LTE, EQ, NEQ, AND, OR, NOT}
