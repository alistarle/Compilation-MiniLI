package ast;

/**
 * Created by thomas on 22/02/16.
 */
public enum Bool {TRUE, FALSE}
